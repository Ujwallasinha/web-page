<?php
$link=mysqli_connect("localhost","root","","Welcome");
$f=$_POST['Email'];
$l=$_POST['Password'];
$query="insert into data values('$f','$l')";
$result=mysqli_query($link,$query);
header('Location: login.html');
mysqli_close($link);
?>